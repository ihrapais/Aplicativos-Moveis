package com.example.implementapet;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText editNomePet, editCPF, editTelefone;
    private PetDao petDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Vincular os campos do layout
        editNomePet = findViewById(R.id.editNome);
        editCPF = findViewById(R.id.editCPF);
        editTelefone = findViewById(R.id.editTelefone);
        Button btnCadastrar = findViewById(R.id.btnCadastrar);
        Button btnListar = findViewById(R.id.btnListar);

        // Inicializar o DAO
        petDao = AppDatabase.getInstance(this).petDao();

        // Configurar o botão Cadastrar
        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomePet = editNomePet.getText().toString().trim();
                String cpf = editCPF.getText().toString().trim();
                String telefone = editTelefone.getText().toString().trim();

                if (!nomePet.isEmpty() && !cpf.isEmpty() && !telefone.isEmpty()) {
                    Pet pet = new Pet();
                    pet.cpf = cpf;
                    pet.nome = nomePet;
                    pet.telefone = telefone;
                    petDao.inserir(pet);
                    Toast.makeText(MainActivity.this, "PET cadastrado!", Toast.LENGTH_SHORT).show();
                    limparCampos();
                } else {
                    Toast.makeText(MainActivity.this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Configurar o botão Listar PETs
        btnListar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListarPetsActivity.class);
                startActivity(intent);
            }
        });
    }

    /**
     * Limpa os campos de texto após o cadastro.
     */
    private void limparCampos() {
        editNomePet.setText("");
        editCPF.setText("");
        editTelefone.setText("");
    }
}