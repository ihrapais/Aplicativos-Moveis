package com.example.implementapet;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Entidade que representa um PET no banco de dados.
 * O CPF do dono é a chave primária.
 */
@Entity(tableName = "Pet")
public class Pet {
    @PrimaryKey
    @NonNull
    public String cpf; // CPF do dono (chave primária)
    public String nome; // Nome do PET
    public String telefone; // Telefone do dono

    /**
     * Método para exibir o PET na ListView.
     * @return String formatada com nome e CPF.
     */
    @Override
    public String toString() {
        return "PET: " + nome + " | CPF do Dono: " + cpf;
    }
}