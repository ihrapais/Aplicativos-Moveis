package com.example.implementapet;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class ListarPetsActivity extends AppCompatActivity {
    private ListView listViewPets;
    private Button btnVoltar;
    private PetDao petDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_pets);

        // Vincular os componentes do layout
        listViewPets = findViewById(R.id.listViewPets);
        btnVoltar = findViewById(R.id.btnVoltar);

        // Inicializar o DAO e obter a lista de PETs
        petDao = AppDatabase.getInstance(this).petDao();
        List<Pet> listaPets = petDao.obterTodos();

        // Configurar o adaptador para a ListView
        ArrayAdapter<Pet> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaPets);
        listViewPets.setAdapter(adapter);

        // Configurar o botão Voltar
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}