package com.example.implementapet;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

/**
 * Interface DAO para operações de banco de dados na tabela Pet.
 */
@Dao
public interface PetDao {
    /**
     * Insere um novo PET no banco de dados.
     * @param pet Objeto Pet a ser inserido.
     */
    @Insert
    void inserir(Pet pet);

    /**
     * Obtém todos os PETs cadastrados.
     * @return Lista de PETs.
     */
    @Query("SELECT * FROM Pet")
    List<Pet> obterTodos();
}