package com.example.implementapet;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

/**
 * Classe que representa o banco de dados Room.
 * Inclui a entidade Pet e fornece o DAO.
 */
@Database(entities = {Pet.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    /**
     * Método abstrato que retorna o DAO para Pet.
     * @return Instância de PetDao.
     */
    public abstract PetDao petDao();

    private static AppDatabase INSTANCE;

    /**
     * Obtém a instância única do banco de dados (Singleton).
     * @param context Contexto da aplicação.
     * @return Instância do banco de dados.
     */
    public static synchronized AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "banco-de-dados")
                    .allowMainThreadQueries() // Permite consultas no thread principal (simplificado)
                    .build();
        }
        return INSTANCE;
    }
}